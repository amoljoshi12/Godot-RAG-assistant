# Godot 4 Knowledge Base

This directory contains a **domain-specific knowledge base** designed for building an **on-device AI assistant for Godot 4 game development**.

The content is structured for:
- Debugging assistance
- Code explanation
- Best-practice guidance
- Retrieval-Augmented Generation (RAG)

This is **not documentation**. It is a curated expert corpus.

---

## Directory Structure

```
knowledge_base/
│
├── docs/          # Core Godot concepts
├── gdscript/      # GDScript language rules and patterns
├── errors/        # Common runtime errors and fixes
├── examples/      # Practical, real-world examples
└── README.md
```

---

## docs/

Conceptual engine knowledge.

- `node.md` – Node fundamentals and lifecycle
- `scene_tree.md` – Scene tree structure and behavior
- `lifecycle.md` – Execution order and timing
- `input.md` – Input handling patterns
- `physics.md` – Physics system rules
- `signals.md` – Event-driven communication

---

## gdscript/

Language-level rules and architecture.

- `syntax.md`
- `variables.md`
- `control_flow.md`
- `functions.md`
- `classes.md`
- `common_patterns.md`

---

## errors/

Focused debugging knowledge.  
Each file covers **one error class only**.

- `null_instance.md`
- `node_not_found.md`
- `invalid_get_index.md`
- `signal_not_firing.md`
- `physics_not_working.md`

---

## examples/

Practical reference implementations.

- `basic_scene_structure.md`
- `character_movement.md`
- `enemy_ai_basic.md`
- `collision_handling.md`

---

## Design Principles

- One concept per file
- Symptoms → Cause → Fix
- Minimal but correct code
- Godot 4–accurate only
- Safe for semantic chunking and embedding

---

## Intended Use

This knowledge base is designed to be used with:
- On-device LLMs
- Vector databases
- RAG pipelines
- Game development assistants

It is **not** meant for direct reading by beginners.

---

## Maintenance Rules

- Do not merge files
- Do not duplicate concepts
- Do not add tutorials
- Add new files only when a concept clearly does not belong elsewhere
