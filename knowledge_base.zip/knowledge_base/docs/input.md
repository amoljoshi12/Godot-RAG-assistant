---
topic: input_handling
engine: godot4
language: gdscript
type: concept
---

# Input Handling (Godot 4)

## What Input Handling Is
Input handling is the system that detects and processes player actions such as keyboard presses, mouse input, and controller events. Most input bugs occur due to incorrect input mapping or using the wrong lifecycle method.

---

## Where Input Code Should Run

Godot provides multiple input callbacks, each with a specific purpose:

- `_input(event)` – Receives all input events
- `_unhandled_input(event)` – Receives input not consumed by UI
- `_process(delta)` – Non-physics input logic
- `_physics_process(delta)` – Movement and physics-based input

Using the wrong callback is one of the most common causes of missing input in Godot.

---

## Error: Input Not Detected

### Symptoms
- Key presses do nothing
- Mouse input is ignored
- Input works inconsistently

### Cause
Input code is placed in the wrong callback or UI elements consume the input.

### Fix

```gdscript
func _input(event):
    if event.is_action_pressed("jump"):
        jump()
```

Use `_unhandled_input()` if UI blocks input.

---

## Error: Action Not Working

### Symptoms
- `is_action_pressed()` always returns false
- Key bindings appear correct but input does nothing

### Cause
The input action is not defined in the Input Map.

### Fix
Define the action in **Project Settings → Input Map**.

```gdscript
if Input.is_action_pressed("move_left"):
    velocity.x = -speed
```

---

## Error: Movement Feels Inconsistent

### Symptoms
- Character speed changes with frame rate
- Movement feels jittery

### Cause
Movement input is handled in `_process()` instead of `_physics_process()`.

### Fix

❌ Incorrect:
```gdscript
func _process(delta):
    velocity.x = speed
```

✅ Correct:
```gdscript
func _physics_process(delta):
    velocity.x = speed
```

Physics-related input must be handled in `_physics_process()`.

---

## Input Actions vs Raw Input

- Input actions are recommended
- Raw key codes are harder to maintain
- Input actions support remapping

### Preferred Pattern
```gdscript
if Input.is_action_just_pressed("attack"):
    attack()
```

---

## Mouse and Keyboard Input

### Mouse Button Input
```gdscript
func _input(event):
    if event is InputEventMouseButton and event.pressed:
        shoot()
```

### Keyboard Input
```gdscript
func _input(event):
    if event is InputEventKey and event.pressed:
        print("Key pressed")
```

---

## Error: UI Blocking Input

### Symptoms
- Input works until a menu opens
- Gameplay input stops when UI is visible

### Cause
UI controls consume input events.

### Fix
Handle gameplay input in `_unhandled_input()`.

```gdscript
func _unhandled_input(event):
    if event.is_action_pressed("pause"):
        toggle_pause()
```

---

## Debugging Checklist for Input Issues

Before assuming engine bugs, check:

- Is the input action defined in the Input Map?
- Is input code in the correct callback?
- Is UI consuming the input?
- Is movement input handled in `_physics_process()`?
- Is the node receiving input focus?
