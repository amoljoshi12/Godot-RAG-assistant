---
topic: lifecycle
engine: godot4
language: gdscript
type: concept
---

# Node Lifecycle (Godot 4)

## What the Node Lifecycle Is
The node lifecycle defines the order in which a node is created, enters the scene tree, becomes ready, processes logic, and is removed. Most Godot runtime bugs happen because code runs at the wrong lifecycle stage.

---

## Lifecycle Order (Critical)

Nodes follow this fixed execution order:

1. `_init()` – Object is created (NOT in the scene tree)
2. `_enter_tree()` – Node enters the scene tree
3. `_ready()` – Node and all children are ready
4. `_process(delta)` – Frame-based logic
5. `_physics_process(delta)` – Fixed-timestep physics logic
6. `_exit_tree()` – Node leaves the scene tree

Accessing nodes outside their valid lifecycle stage causes errors.

---

## Error: Using Scene Logic in `_init()`

### Symptoms
- `Null instance` error
- Child nodes are `null`
- Node paths fail unexpectedly

### Cause
During `_init()`, the node is not part of the scene tree. Child nodes do not exist yet.

### Fix

❌ Incorrect:
```gdscript
func _init():
    $Sprite2D.visible = false
```

✅ Correct:
```gdscript
func _ready():
    $Sprite2D.visible = false
```

Use `_init()` only for basic variable initialization.

---

## Error: Confusing `_process()` and `_physics_process()`

### Symptoms
- Movement feels inconsistent
- Physics behaves differently at different frame rates
- Character teleports or jitters

### Cause
Physics logic is placed in `_process()` instead of `_physics_process()`.

### Fix

❌ Incorrect:
```gdscript
func _process(delta):
    velocity.x = speed
    move_and_slide()
```

✅ Correct:
```gdscript
func _physics_process(delta):
    velocity.x = speed
    move_and_slide()
```

Physics logic must run in `_physics_process()`.

---

## Error: Child Nodes Not Ready

### Symptoms
- Signals not connected
- Child references are `null`
- Logic works inconsistently

### Cause
Parent `_ready()` may execute before dependent child logic is prepared.

### Fix
Defer logic or wait for readiness.

```gdscript
func _ready():
    await ready
    child_node.initialize()
```

---

## `_enter_tree()` vs `_ready()`

- `_enter_tree()` runs when the node enters the scene tree
- `_ready()` runs after the node and all its children are ready
- Use `_enter_tree()` for registration logic
- Use `_ready()` for scene interaction

Access child nodes only in `_ready()` or later.

---

## Error: Logic Running After Node Removal

### Symptoms
- Errors after `queue_free()`
- Invalid instance access
- Signals firing unexpectedly

### Cause
Code executes after the node has exited the scene tree.

### Fix
Check node validity before executing logic.

```gdscript
if is_instance_valid(self):
    do_something()
```

---

## Debugging Checklist for Lifecycle Issues

Before debugging complex logic, verify:

- Is the code running in the correct lifecycle method?
- Is the node already inside the scene tree?
- Are child nodes ready?
- Is physics logic inside `_physics_process()`?
- Has the node already exited the scene tree?
