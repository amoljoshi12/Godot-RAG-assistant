---
topic: nodes
engine: godot4
language: gdscript
type: concept
---

# Node (Godot 4)

## What a Node Is
A Node is the fundamental unit of a Godot scene. Every object exists as a node inside the scene tree and becomes fully functional only after entering the scene tree.

---

## Important Properties of Nodes

- A node has exactly one parent
- A node may have multiple children
- A node must be inside the scene tree to function correctly
- Node paths are case-sensitive
- Accessing nodes too early causes null instance errors

---

## Node Lifecycle (Overview)

Nodes follow a strict lifecycle order:

1. `_init()` – Object is created (not in the scene tree)
2. `_enter_tree()` – Node enters the scene tree
3. `_ready()` – Node and all children are ready
4. `_process(delta)` / `_physics_process(delta)` – Runtime logic
5. `_exit_tree()` – Node leaves the scene tree

Most node-related bugs come from running code before `_ready()`.

---

## Error: Accessing Child Nodes Too Early

### Symptoms
- `Null instance` error
- `Invalid get index`
- Child node reference is `null`

### Cause
Child nodes do not exist in the scene tree during `_init()` or before `_ready()` runs.

### Fix

❌ Incorrect:
```gdscript
func _init():
    $Sprite2D.visible = false
```

✅ Correct:
```gdscript
func _ready():
    $Sprite2D.visible = false
```

Always access child nodes in `_ready()` or later.

---

## Error: Wrong Node Path

### Symptoms
- `Node not found`
- `Invalid get index`
- Code breaks after scene structure changes

### Cause
The node path is incorrect or the scene hierarchy has changed.

### Fix

```gdscript
var weapon = get_node_or_null("Player/Weapon")
if weapon:
    weapon.shoot()
```

Verify node paths using the Scene dock.

---

## Node Validity and Lifetime

Nodes can be removed from the scene tree using `queue_free()`.

Accessing a node after it has been freed causes invalid reference errors.

### Safe Pattern
```gdscript
if is_instance_valid(enemy):
    enemy.attack()
```

Once a node is freed, it should not be used again.

---

## Signals and Node Lifetime

- Signals stop working if the emitting or receiving node is freed
- Connecting signals before `_ready()` can fail
- Always connect signals when nodes are ready

```gdscript
func _ready():
    button.pressed.connect(_on_button_pressed)
```

---

## Debugging Checklist for Node Issues

Before debugging complex logic, check:

- Is the node inside the scene tree?
- Is the node path correct?
- Is the code running after `_ready()`?
- Has the node been freed?
- Is the node type correct (`Node2D`, `CharacterBody2D`, etc.)?
