---
topic: physics
engine: godot4
language: gdscript
type: concept
---

# Physics (Godot 4)

## What the Physics System Is
Godot’s physics system handles movement, collisions, and physical interactions using a fixed timestep. Most physics bugs occur when movement or collision logic runs in the wrong lifecycle method or uses the wrong body type.

---

## Physics Body Types (Critical Difference)

- `CharacterBody2D` – Script-controlled movement (players, enemies)
- `RigidBody2D` – Physics-simulated objects (forces, impulses)
- `StaticBody2D` – Immovable collision objects
- `Area2D` – Detection and triggers (no physical response)

Using the wrong body type causes silent and confusing bugs.

---

## Where Physics Code Must Run

Physics logic must run in:

- `_physics_process(delta)`

Using `_process()` for physics causes frame-rate dependent behavior.

---

## Error: Character Teleports or Jitters

### Symptoms
- Character snaps or teleports
- Movement feels jittery
- Speed changes with frame rate

### Cause
Movement logic is placed in `_process()` instead of `_physics_process()`.

### Fix

❌ Incorrect:
```gdscript
func _process(delta):
    velocity.x = speed
    move_and_slide()
```

✅ Correct:
```gdscript
func _physics_process(delta):
    velocity.x = speed
    move_and_slide()
```

---

## Error: Character Does Not Move

### Symptoms
- No movement despite input
- `velocity` updates but position does not change

### Cause
`move_and_slide()` or `move_and_collide()` is never called.

### Fix
Always apply movement using a physics method.

```gdscript
func _physics_process(delta):
    velocity.x = speed
    move_and_slide()
```

---

## Error: Collisions Not Detected

### Symptoms
- Player passes through objects
- Collision callbacks never fire

### Cause
Missing collision shapes or incorrect collision layers/masks.

### Fix
- Ensure a `CollisionShape2D` exists
- Verify collision layers and masks
- Confirm compatible body types

---

## Collision Layers and Masks (Critical)

- **Layer**: what the object is
- **Mask**: what the object collides with

Two bodies collide only if one body’s mask includes the other’s layer.

Misconfigured layers cause silent collision failures.

---

## Error: Gravity Not Applied

### Symptoms
- Character floats
- No falling behavior

### Cause
`CharacterBody2D` does not apply gravity automatically.

### Fix
Apply gravity manually every physics frame.

```gdscript
func _physics_process(delta):
    velocity.y += gravity * delta
    move_and_slide()
```

---

## RigidBody2D vs CharacterBody2D

- `RigidBody2D` should NOT be moved manually
- `CharacterBody2D` MUST be moved manually

### Incorrect Usage
```gdscript
$RigidBody2D.position.x += 10
```

### Correct Usage
Use forces or impulses for `RigidBody2D`.

---

## Physics Timestep

- Physics runs at a fixed rate (default 60 Hz)
- Frame rate does not affect physics consistency
- Always use `delta` for calculations

Ignoring this causes inconsistent movement.

---

## Debugging Checklist for Physics Issues

Before assuming logic bugs, check:

- Is physics code in `_physics_process()`?
- Is the correct body type used?
- Is `move_and_slide()` or `move_and_collide()` called?
- Are collision layers and masks configured correctly?
- Is gravity applied manually where required?
- Does every physics body have a collision shape?
