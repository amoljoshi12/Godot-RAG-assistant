---
topic: scene_tree
engine: godot4
language: gdscript
type: concept
---

# Scene Tree (Godot 4)

## What the Scene Tree Is
The scene tree is the hierarchical structure that contains all active nodes in a running Godot game. A node becomes functional only after it is added to the scene tree.

---

## Key Rules of the Scene Tree

- Every running game has exactly one scene tree
- Nodes must be inside the scene tree to process logic
- Parent nodes control the lifetime of their children
- Removing a parent removes all its children
- Scene structure directly affects node paths

Most runtime bugs are caused by incorrect assumptions about the scene tree.

---

## How Nodes Enter the Scene Tree

Nodes enter the scene tree in two main ways:

1. Being part of the main scene loaded at startup
2. Being added dynamically using `add_child()`

### Example
```gdscript
var enemy = EnemyScene.instantiate()
add_child(enemy)
```

Until `add_child()` is called, the node does not exist in the scene tree.

---

## Error: Node Not in Scene Tree

### Symptoms
- `_ready()` is never called
- Signals do not fire
- Node logic does not run

### Cause
The node was instantiated but never added to the scene tree.

### Fix
Add the node to a parent that is already inside the scene tree.

```gdscript
var bullet = BulletScene.instantiate()
get_tree().current_scene.add_child(bullet)
```

---

## Error: Adding Child Too Early

### Symptoms
- Child behaves inconsistently
- `_ready()` order issues
- Child references are `null`

### Cause
The parent node has not yet entered the scene tree.

### Fix
Add children after the parent reaches `_ready()`.

```gdscript
func _ready():
    add_child(child_node)
```

---

## Parent–Child Lifetime Relationship

- When a parent node is freed, all its children are freed
- Child nodes should not outlive their parent
- Holding references to freed children causes invalid access errors

### Safe Pattern
```gdscript
if is_instance_valid(weapon):
    weapon.fire()
```

---

## Scene Instancing

Scenes can be reused by instancing them multiple times.

```gdscript
var enemy = EnemyScene.instantiate()
add_child(enemy)
```

Each instance:
- Has its own state
- Has its own position
- Exists independently in the scene tree

---

## Debugging Checklist for Scene Tree Issues

Before assuming complex logic bugs, check:

- Is the node added to the scene tree?
- Is the parent node inside the scene tree?
- Is `add_child()` called at the correct time?
- Has the node been freed earlier than expected?
- Is the node path correct for the current hierarchy?
