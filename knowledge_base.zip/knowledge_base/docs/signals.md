---
topic: signals
engine: godot4
language: gdscript
type: concept
---

# Signals (Godot 4)

## What Signals Are
Signals are Godot’s event system used for communication between nodes. They allow nodes to react to events without tight coupling. Most signal bugs come from incorrect connection timing or node lifetime issues.

---

## When Signals Should Be Used

Signals are best used for:
- Button presses
- Collision or area events
- Animation completion
- State changes
- Custom gameplay events

Signals should be preferred over polling logic.

---

## Where Signals Should Be Connected

Signals should be connected only after nodes enter the scene tree.

Best place:
- `_ready()`

Avoid connecting signals in `_init()`.

---

## Error: Signal Not Firing

### Symptoms
- Connected function never runs
- No errors, but nothing happens
- Expected event does not trigger

### Cause
The signal was never connected, or it was connected before the node entered the scene tree.

### Fix

❌ Incorrect:
```gdscript
func _init():
    button.pressed.connect(_on_button_pressed)
```

✅ Correct:
```gdscript
func _ready():
    button.pressed.connect(_on_button_pressed)
```

Always connect signals in `_ready()`.

---

## Error: Signal Connected Multiple Times

### Symptoms
- Function runs multiple times
- Duplicate actions occur
- Unexpected repeated behavior

### Cause
The same signal is connected more than once, often inside `_process()` or repeated `_ready()` calls.

### Fix
Check if the signal is already connected.

```gdscript
if not button.pressed.is_connected(_on_button_pressed):
    button.pressed.connect(_on_button_pressed)
```

---

## Error: Target Method Not Found

### Symptoms
- Signal connection fails silently
- Runtime error when signal fires

### Cause
The connected method does not exist or has the wrong signature.

### Fix
Ensure the method exists and matches the signal signature.

```gdscript
func _on_button_pressed():
    print("Button pressed")
```

---

## Custom Signals

Nodes can define and emit their own signals.

### Defining a Custom Signal
```gdscript
signal health_changed(new_health)
```

### Emitting a Signal
```gdscript
health_changed.emit(current_health)
```

### Connecting a Custom Signal
```gdscript
func _ready():
    health_changed.connect(_on_health_changed)
```

---

## Signal Lifetime Rules

- Signals stop working when either node is freed
- Signals connected to freed nodes are automatically disconnected
- Accessing freed nodes causes invalid instance errors

Always consider node lifetime when using signals.

---

## Debugging Checklist for Signal Issues

Before assuming logic bugs, check:

- Is the signal connected?
- Is the connection done in `_ready()`?
- Is the signal connected only once?
- Does the target method exist?
- Are both nodes still alive?
