---
topic: error_invalid_get_index
engine: godot4
language: gdscript
type: error
---

# Invalid Get Index Error (Godot 4)

## What the Invalid Get Index Error Is
An invalid get index error occurs when code tries to access a property, array index, or dictionary key that does not exist. This error often appears alongside null instance and node path issues.

---

## Common Error Messages

- `Invalid get index`
- `Invalid get index 'x' (on base: 'Nil')`
- `Invalid get index 'position'`
- `Invalid get index on base Array`
- `Invalid get index on base Dictionary`

These indicate that the requested index or property is invalid for the given object.

---

## Root Causes (Most Common)

- Accessing properties on a `null` object
- Using an index outside array bounds
- Accessing a missing dictionary key
- Assuming a node exists when it does not
- Using wrong node type assumptions

---

## Error: Accessing Property on `null`

### Symptoms
- Error occurs at runtime
- Property access fails immediately

### Cause
The variable is `null` when the property is accessed.

### Fix
Check for validity before accessing properties.

```gdscript
if player:
    player.position.x += 10
```

---

## Error: Array Index Out of Bounds

### Symptoms
- Crash when accessing array
- Index-related runtime error

### Cause
Index exceeds array size.

### Fix
Check array size before accessing.

```gdscript
if index < items.size():
    print(items[index])
```

---

## Error: Missing Dictionary Key

### Symptoms
- Runtime error when accessing dictionary
- Unexpected crashes

### Cause
Key does not exist in dictionary.

### Fix
Check for key existence.

```gdscript
if data.has("health"):
    health = data["health"]
```

---

## Error: Wrong Node Type Assumption

### Symptoms
- Property does not exist
- Method call fails

### Cause
Assuming a node has properties of a different type.

### Fix
Confirm node type or use casting.

```gdscript
var body := node as CharacterBody2D
if body:
    body.velocity.x = 100
```

---

## Prevention Checklist

To avoid invalid get index errors:

- Check objects for `null`
- Validate array indices
- Use `Dictionary.has()`
- Verify node types
- Avoid assumptions about scene structure
