---
topic: error_node_not_found
engine: godot4
language: gdscript
type: error
---

# Node Not Found Error (Godot 4)

## What the Node Not Found Error Is
A node not found error occurs when code tries to access a node path that does not exist in the current scene tree. This usually happens after scene refactors or incorrect assumptions about hierarchy.

---

## Common Error Messages

- `Node not found`
- `Invalid get index`
- `Invalid call. Nonexistent function`
- `Attempt to call function on a null instance`

These errors indicate that the requested node path does not resolve to a valid node.

---

## Root Causes (Most Common)

- Incorrect node path
- Scene hierarchy changed after refactor
- Node not added to the scene tree
- Using relative paths incorrectly
- Accessing nodes before `_ready()`

---

## Error: Incorrect Node Path

### Symptoms
- Code works in one scene but not another
- Node access fails after renaming or moving nodes

### Cause
The hardcoded node path no longer matches the scene hierarchy.

### Fix
Verify the path using the Scene dock and use safer access.

```gdscript
var weapon = get_node_or_null("Player/Weapon")
if weapon:
    weapon.shoot()
```

---

## Error: Using Relative Paths Incorrectly

### Symptoms
- Node works only when script is attached to a specific parent
- Same script breaks when reused

### Cause
Relative paths depend on the script’s position in the scene tree.

### Fix
Use absolute paths or refactor to pass references.

```gdscript
var player = get_node_or_null("/root/Main/Player")
```

---

## Error: Node Not Added to Scene Tree

### Symptoms
- `_ready()` never runs
- Node path access fails

### Cause
The node was instantiated but never added with `add_child()`.

### Fix
Ensure the node is added to a parent in the scene tree.

```gdscript
var enemy = EnemyScene.instantiate()
add_child(enemy)
```

---

## Error: Accessing Node Too Early

### Symptoms
- Node is `null` on scene load
- Errors during initialization

### Cause
Node access happens in `_init()` or before `_ready()`.

### Fix
Access nodes in `_ready()` or later lifecycle methods.

---

## Prevention Checklist

To avoid node not found errors:

- Recheck node paths after refactors
- Prefer `get_node_or_null()` over `get_node()`
- Avoid deep hardcoded paths
- Pass node references instead of paths when possible
- Access nodes only after `_ready()`
- Ensure instantiated nodes are added to the scene tree
