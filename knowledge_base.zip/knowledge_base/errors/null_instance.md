---
topic: error_null_instance
engine: godot4
language: gdscript
type: error
---

# Null Instance Error (Godot 4)

## What the Null Instance Error Is
A null instance error occurs when code tries to access a node or object reference that is `null` or no longer valid. This is one of the most common runtime errors in Godot.

---

## Common Error Messages

- `Attempt to call function on a null instance`
- `Invalid get index`
- `Nil is not an object`

These errors indicate that the reference does not point to a valid object.

---

## Root Causes (Most Common)

- Accessing child nodes before `_ready()`
- Incorrect node paths
- Nodes freed with `queue_free()`
- Variables never assigned
- Scene instanced but not added to the scene tree

---

## Error: Accessing Node Too Early

### Symptoms
- Error occurs on scene load
- `$NodeName` is `null`

### Cause
Node access happens in `_init()` or before the node enters the scene tree.

### Fix

❌ Incorrect:
```gdscript
func _init():
    $Sprite2D.visible = false
```

✅ Correct:
```gdscript
func _ready():
    $Sprite2D.visible = false
```

Always access nodes in `_ready()` or later.

---

## Error: Wrong Node Path

### Symptoms
- Node works sometimes, fails after refactor
- `get_node()` returns `null`

### Cause
The node path does not match the current scene hierarchy.

### Fix
Use `get_node_or_null()` and verify paths.

```gdscript
var weapon = get_node_or_null("Player/Weapon")
if weapon:
    weapon.shoot()
```

---

## Error: Node Freed but Still Used

### Symptoms
- Error occurs after `queue_free()`
- Signals fire on invalid nodes

### Cause
A reference is kept after the node has been freed.

### Fix
Check instance validity before use.

```gdscript
if is_instance_valid(enemy):
    enemy.attack()
```

---

## Error: Variable Never Assigned

### Symptoms
- Variable is always `null`
- Logic never executes

### Cause
Variable depends on runtime assignment that never happens.

### Fix
Initialize variables explicitly or assign them in `_ready()`.

```gdscript
func _ready():
    player = get_node("Player")
```

---

## Prevention Checklist

To avoid null instance errors:

- Access nodes only after `_ready()`
- Validate node paths after refactors
- Use `get_node_or_null()` instead of `get_node()`
- Check `is_instance_valid()` for dynamic nodes
- Avoid using freed nodes
- Initialize variables clearly
