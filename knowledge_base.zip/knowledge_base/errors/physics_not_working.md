---
topic: error_physics_not_working
engine: godot4
language: gdscript
type: error
---

# Physics Not Working Error (Godot 4)

## What the Physics Not Working Error Is
A physics not working error occurs when movement, collisions, or gravity behave incorrectly or not at all. This usually results from using the wrong node type, wrong lifecycle method, or missing physics setup.

---

## Common Error Symptoms

- Character does not move
- Character teleports or jitters
- Collisions do not trigger
- Gravity does not apply
- Physics behaves differently at different frame rates

---

## Root Causes (Most Common)

- Using `_process()` instead of `_physics_process()`
- Wrong physics body type
- Missing `CollisionShape2D`
- Incorrect collision layers or masks
- Forgetting to apply movement functions
- Gravity not applied manually

---

## Error: Movement Code in `_process()`

### Symptoms
- Jittery or inconsistent movement
- Speed varies with FPS

### Cause
Physics logic placed in `_process()`.

### Fix

❌ Incorrect:
```gdscript
func _process(delta):
    velocity.x = speed
    move_and_slide()
```

✅ Correct:
```gdscript
func _physics_process(delta):
    velocity.x = speed
    move_and_slide()
```

---

## Error: Wrong Physics Body Type

### Symptoms
- Movement code runs but node does not move
- Collisions behave unexpectedly

### Cause
Using `RigidBody2D` for manual movement or `CharacterBody2D` incorrectly.

### Fix
Choose the correct body type:

- `CharacterBody2D` → manual movement
- `RigidBody2D` → force-based movement
- `StaticBody2D` → immovable objects

---

## Error: Missing Collision Shape

### Symptoms
- Object passes through everything
- No collision events

### Cause
No `CollisionShape2D` attached or shape disabled.

### Fix
Add and enable a `CollisionShape2D` node.

---

## Error: Collisions Not Triggering

### Symptoms
- No collision callbacks
- Overlapping objects ignore each other

### Cause
Collision layers and masks are misconfigured.

### Fix
Verify layers and masks match between objects.

---

## Error: Gravity Not Applied

### Symptoms
- Character floats
- No falling behavior

### Cause
`CharacterBody2D` does not apply gravity automatically.

### Fix
Apply gravity manually every physics frame.

```gdscript
func _physics_process(delta):
    velocity.y += gravity * delta
    move_and_slide()
```

---

## Error: Movement Function Never Called

### Symptoms
- Velocity updates but position stays the same

### Cause
Missing `move_and_slide()` or `move_and_collide()` call.

### Fix
Always apply movement explicitly.

---

## Prevention Checklist

To avoid physics issues:

- Put physics logic in `_physics_process()`
- Use the correct physics body type
- Ensure `CollisionShape2D` exists and is enabled
- Verify collision layers and masks
- Apply gravity manually when required
- Always call movement functions
