---
topic: error_signal_not_firing
engine: godot4
language: gdscript
type: error
---

# Signal Not Firing Error (Godot 4)

## What the Signal Not Firing Error Is
A signal not firing error occurs when a signal is expected to trigger a function, but the connected method never runs. This is usually caused by incorrect connection timing, node lifetime issues, or duplicate/missing connections.

---

## Common Error Symptoms

- Button pressed but nothing happens
- Signal callback never executes
- No error messages, but logic does not run
- Signal works sometimes but not always

---

## Root Causes (Most Common)

- Signal not connected
- Signal connected before `_ready()`
- Node emitting or receiving signal was freed
- Signal connected multiple times incorrectly
- Wrong method signature

---

## Error: Signal Never Connected

### Symptoms
- Signal never fires
- Callback function never runs

### Cause
Signal connection code was never executed.

### Fix
Ensure the signal is connected in `_ready()`.

```gdscript
func _ready():
    button.pressed.connect(_on_button_pressed)
```

---

## Error: Signal Connected Too Early

### Symptoms
- Signal appears connected but never fires
- Node reference is `null`

### Cause
Signal was connected in `_init()` or before the node entered the scene tree.

### Fix
Move signal connection to `_ready()`.

```gdscript
func _ready():
    button.pressed.connect(_on_button_pressed)
```

---

## Error: Node Freed Before Signal Fires

### Symptoms
- Signal stops firing after some time
- Errors after `queue_free()`

### Cause
Either the emitter or receiver node was freed.

### Fix
Ensure both nodes are valid when the signal is expected to fire.

```gdscript
if is_instance_valid(button):
    button.pressed.connect(_on_button_pressed)
```

---

## Error: Signal Connected Multiple Times

### Symptoms
- Callback runs multiple times
- Unexpected repeated behavior

### Cause
Signal is connected repeatedly, often inside `_process()`.

### Fix
Check connection before connecting.

```gdscript
if not button.pressed.is_connected(_on_button_pressed):
    button.pressed.connect(_on_button_pressed)
```

---

## Error: Wrong Method Signature

### Symptoms
- Runtime error when signal fires
- Callback not called

### Cause
Connected method signature does not match the signal.

### Fix
Ensure the method signature matches the signal definition.

```gdscript
func _on_button_pressed():
    print("Pressed")
```

---

## Prevention Checklist

To avoid signal not firing errors:

- Connect signals in `_ready()` only
- Ensure signals are connected exactly once
- Verify emitter and receiver nodes are alive
- Match callback method signatures
- Avoid connecting signals inside `_process()`
