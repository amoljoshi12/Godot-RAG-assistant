---
topic: example_basic_scene_structure
engine: godot4
language: gdscript
type: example
---

# Basic Scene Structure (Godot 4)

## What This Example Demonstrates
This example shows a clean, minimal scene structure used in most Godot games. Many bugs originate from poor scene organization rather than code errors.

---

## Example Scene Tree

```
Main (Node)
├── Player (CharacterBody2D)
│   ├── Sprite2D
│   ├── CollisionShape2D
│   └── Camera2D
├── Enemies (Node)
│   └── Enemy (CharacterBody2D)
│       ├── Sprite2D
│       └── CollisionShape2D
└── UI (CanvasLayer)
    └── HUD (Control)
```

---

## Why This Structure Works

- Clear separation of responsibilities
- Player logic isolated from enemies
- UI separated from gameplay nodes
- Easy to extend and debug

This structure scales well for small and medium projects.

---

## Player Script Example

```gdscript
extends CharacterBody2D

@export var speed: int = 200

func _physics_process(delta):
    var direction = Input.get_axis("move_left", "move_right")
    velocity.x = direction * speed
    move_and_slide()
```

---

## Enemy Script Example

```gdscript
extends CharacterBody2D

@export var speed: int = 100

func _physics_process(delta):
    velocity.x = -speed
    move_and_slide()
```

---

## Common Mistakes

### Putting UI Inside Gameplay Nodes
UI nodes should live under a `CanvasLayer`, not under `Player` or `Enemy`.

### Mixing Responsibilities
Avoid handling input, UI, and AI in the same node.

---

## Debugging Checklist

Before restructuring your scene, check:

- Are nodes grouped logically?
- Is UI separated from gameplay?
- Does each node have a single responsibility?
- Are reusable elements instanced as scenes?
