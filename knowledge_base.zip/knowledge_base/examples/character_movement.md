---
topic: example_character_movement
engine: godot4
language: gdscript
type: example
---

# Character Movement (Godot 4)

## What This Example Demonstrates
This example shows a correct and minimal implementation of 2D character movement using `CharacterBody2D`. Movement bugs are among the most common issues in Godot projects.

---

## Scene Setup

```
Player (CharacterBody2D)
├── Sprite2D
└── CollisionShape2D
```

The script is attached to the `Player` node.

---

## Basic Movement Script

```gdscript
extends CharacterBody2D

@export var speed: int = 200
@export var gravity: int = 900

func _physics_process(delta):
    var direction := Input.get_axis("move_left", "move_right")

    velocity.x = direction * speed
    velocity.y += gravity * delta

    move_and_slide()
```

---

## Why This Works

- Uses `CharacterBody2D` (correct body type)
- Movement logic runs in `_physics_process()`
- Uses input actions instead of raw keys
- Gravity is applied manually
- `move_and_slide()` is always called

---

## Common Mistakes

### Using `_process()` for Movement
Causes frame-rate dependent movement and jitter.

### Forgetting `move_and_slide()`
Velocity updates but position never changes.

### No Gravity
Character floats forever.

---

## Debugging Checklist

Before changing your movement code, check:

- Is the node a `CharacterBody2D`?
- Is movement in `_physics_process()`?
- Are input actions defined in the Input Map?
- Is gravity applied manually?
- Is `move_and_slide()` called every frame?
