---
topic: example_collision_handling
engine: godot4
language: gdscript
type: example
---

# Collision Handling (Godot 4)

## What This Example Demonstrates
This example shows correct collision handling in Godot 4 using `CharacterBody2D`, collision layers/masks, and collision callbacks. Many collision bugs are caused by misconfiguration rather than code errors.

---

## Scene Setup

```
Player (CharacterBody2D)
├── Sprite2D
└── CollisionShape2D

Enemy (CharacterBody2D)
├── Sprite2D
└── CollisionShape2D
```

Both bodies must have:
- A `CollisionShape2D`
- Correct collision layers and masks

---

## Collision Layers Example

- Player layer: 1
- Enemy layer: 2
- Player mask: 2
- Enemy mask: 1

This allows Player ↔ Enemy collisions.

---

## Basic Collision Detection (CharacterBody2D)

```gdscript
extends CharacterBody2D

func _physics_process(delta):
    move_and_slide()

    for i in get_slide_collision_count():
        var collision = get_slide_collision(i)
        if collision.get_collider().is_in_group("enemy"):
            print("Collided with enemy")
```

---

## Collision Using Area2D (Recommended for Triggers)

### Scene
```
Hitbox (Area2D)
└── CollisionShape2D
```

### Script
```gdscript
func _on_Hitbox_body_entered(body):
    if body.is_in_group("enemy"):
        body.take_damage(10)
```

---

## Why This Works

- `CharacterBody2D` handles physical collision
- `Area2D` handles detection and triggers
- Collision layers/masks control interaction
- Groups avoid fragile node paths

---

## Common Mistakes

### Missing CollisionShape2D
No collisions will ever occur.

### Layers and Masks Don’t Match
Objects visually overlap but never collide.

### Using Node Paths for Collision Logic
Breaks easily when scenes change.

---

## Debugging Checklist

Before debugging collision code, check:

- Does every body have a CollisionShape2D?
- Are collision layers and masks set correctly?
- Is collision logic in `_physics_process()`?
- Are groups used for identification?
- Is `move_and_slide()` being called?
