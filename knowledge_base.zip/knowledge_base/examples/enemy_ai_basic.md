---
topic: example_enemy_ai_basic
engine: godot4
language: gdscript
type: example
---

# Basic Enemy AI (Godot 4)

## What This Example Demonstrates
This example shows a simple, reliable enemy AI that patrols and chases the player when in range. It demonstrates correct use of `CharacterBody2D`, physics processing, and clean state-based logic.

---

## Scene Setup

```
Enemy (CharacterBody2D)
├── Sprite2D
├── CollisionShape2D
└── DetectionArea (Area2D)
    └── CollisionShape2D
```

- The script is attached to `Enemy`
- `DetectionArea` detects the player using collision layers/masks

---

## Enemy AI Script

```gdscript
extends CharacterBody2D

@export var speed: int = 120
@export var chase_speed: int = 180
@export var gravity: int = 900

var state := "patrol"
var player: Node2D = null

func _physics_process(delta):
    velocity.y += gravity * delta

    match state:
        "patrol":
            patrol()
        "chase":
            chase()

    move_and_slide()

func patrol():
    velocity.x = speed

func chase():
    if not player:
        state = "patrol"
        return
    velocity.x = sign(player.global_position.x - global_position.x) * chase_speed

func _on_DetectionArea_body_entered(body):
    if body.is_in_group("player"):
        player = body
        state = "chase"

func _on_DetectionArea_body_exited(body):
    if body == player:
        player = null
        state = "patrol"
```

---

## Why This Works

- Uses a **state pattern** (`patrol` / `chase`)
- AI logic runs in `_physics_process()`
- Player detection handled via `Area2D`
- Guard clauses prevent null access
- Clean separation of detection and movement

---

## Common Mistakes

### Accessing Player Directly via Paths
Breaks when scenes change. Use signals or detection instead.

### No Guard Clauses
Causes null instance errors when player disappears.

### AI Logic in `_process()`
Leads to inconsistent movement.

---

## Debugging Checklist

Before debugging AI behavior, check:

- Is the enemy a `CharacterBody2D`?
- Is gravity applied?
- Are collision layers/masks set correctly?
- Is the player added to the `"player"` group?
- Is AI logic running in `_physics_process()`?
