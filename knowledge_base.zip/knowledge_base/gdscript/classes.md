---
topic: gdscript_classes
engine: godot4
language: gdscript
type: language
---

# Classes (GDScript – Godot 4)

## What Classes Are
Classes define reusable object blueprints. In Godot, every script is a class, and most architecture bugs come from misunderstanding inheritance, initialization order, or class responsibilities.

---

## Script Classes in Godot

Every `.gd` file defines a class automatically.

```gdscript
extends Node2D
```

This creates a class that inherits from `Node2D`.

---

## Class Inheritance

Classes can inherit from other classes.

```gdscript
extends CharacterBody2D
```

Inheritance allows:
- Code reuse
- Shared behavior
- Cleaner architecture

---

## Error: Wrong Base Class

### Symptoms
- Methods not found
- Properties missing
- Runtime errors

### Cause
The script extends an incorrect base class.

### Fix
Ensure the script extends the correct Godot type.

```gdscript
extends CharacterBody2D
```

---

## Class Variables vs Instance Variables

- Class variables belong to the class
- Instance variables belong to each object

### Correct Pattern
```gdscript
var health: int = 100
```

Each instance gets its own `health`.

---

## Error: Shared State Between Instances

### Symptoms
- One object affects another unexpectedly
- Values sync across instances

### Cause
Using `static` variables incorrectly.

### Fix
Avoid `static` unless shared state is intentional.

```gdscript
static var total_enemies = 0
```

---

## `_init()` vs `_ready()` in Classes

- `_init()` → object construction
- `_ready()` → scene tree ready

### Rule
- Do NOT access nodes in `_init()`
- Use `_ready()` for scene interaction

---

## Error: Overriding Without Calling `super()`

### Symptoms
- Parent logic does not execute
- Inherited behavior breaks

### Cause
Overridden method does not call parent implementation.

### Fix
Call `super()` when required.

```gdscript
func _ready():
    super()
    initialize()
```

---

## Inner Classes

GDScript supports inner classes.

```gdscript
class Weapon:
    var damage: int = 10
```

Use sparingly for small helper structures.

---

## `class_name` Keyword

`class_name` registers a script globally.

```gdscript
class_name Enemy
extends CharacterBody2D
```

Allows:
- Global access
- Cleaner instancing

---

## Error: Circular Dependencies

### Symptoms
- Script load failures
- Editor errors
- Unexpected crashes

### Cause
Two classes depend on each other directly.

### Fix
Refactor to remove circular references or use signals.

---

## Debugging Checklist for Class Issues

Before assuming engine bugs, check:

- Is the correct base class extended?
- Are lifecycle methods used correctly?
- Is shared state intentional?
- Are overridden methods calling `super()`?
- Are there circular dependencies?
