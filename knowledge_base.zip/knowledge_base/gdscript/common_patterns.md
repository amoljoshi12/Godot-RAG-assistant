---
topic: gdscript_common_patterns
engine: godot4
language: gdscript
type: language
---

# Common Patterns (GDScript – Godot 4)

## What Common Patterns Are
Common patterns are proven ways to structure logic in Godot projects. Most large-project bugs are not syntax errors, but architectural mistakes caused by missing or misused patterns.

---

## State Pattern (Very Common)

Used for player states, enemy AI, menus, etc.

### Pattern
```gdscript
var state = "idle"

func _physics_process(delta):
    match state:
        "idle":
            idle_state()
        "attack":
            attack_state()
        _:
            idle_state()
```

### Why It Works
- Keeps logic organized
- Prevents conflicting behaviors
- Easy to debug and extend

---

## Guard Clause Pattern (Early Return)

Prevents invalid logic execution.

```gdscript
func attack(target):
    if not target:
        return
    if target.health <= 0:
        return
    target.take_damage(10)
```

### Use When
- Preconditions must be met
- Deep nesting starts appearing

---

## Signal-Based Communication

Nodes should communicate using signals, not direct references.

### Pattern
```gdscript
signal died

func die():
    died.emit()
```

### Why It Matters
- Reduces coupling
- Prevents circular dependencies
- Makes systems reusable

---

## Manager Node Pattern

One node manages a specific responsibility.

### Examples
- GameManager
- AudioManager
- UIManager

### Pattern
```gdscript
class_name GameManager
extends Node

var score = 0
```

Avoid turning managers into god objects.

---

## Error: God Object Pattern

### Symptoms
- One script controls everything
- Difficult to debug or extend

### Cause
Putting unrelated responsibilities into a single class.

### Fix
Split responsibilities into smaller nodes.

---

## Factory Pattern (Scene Instancing)

Used to create objects dynamically.

```gdscript
func spawn_enemy():
    var enemy = EnemyScene.instantiate()
    add_child(enemy)
```

Centralizing instancing avoids duplication and bugs.

---

## Object Pooling Pattern

Reuse objects instead of creating and freeing repeatedly.

### Use When
- Bullets
- Particles
- Enemies

### Basic Pattern
```gdscript
var pool = []

func get_bullet():
    if pool.size() > 0:
        return pool.pop_back()
    return BulletScene.instantiate()
```

---

## Error: Excessive `queue_free()`

### Symptoms
- Performance drops
- GC spikes

### Cause
Constant creation and destruction of nodes.

### Fix
Use object pooling.

---

## Data-Driven Design

Separate data from logic.

### Example
```gdscript
@export var speed: int = 200
@export var health: int = 100
```

Allows tuning without code changes.

---

## Debugging Checklist for Pattern Issues

Before rewriting systems, check:

- Is one node doing too much?
- Are signals used instead of direct calls?
- Is logic duplicated across scripts?
- Are states mutually exclusive?
- Is object pooling needed?
