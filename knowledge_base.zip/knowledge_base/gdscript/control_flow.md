---
topic: gdscript_control_flow
engine: godot4
language: gdscript
type: language
---

# Control Flow (GDScript – Godot 4)

## What Control Flow Is
Control flow determines how and when code executes. Most logic bugs in Godot are caused by incorrect conditions, missing branches, or code unintentionally running every frame.

---

## Error: Condition Always True or False

### Symptoms
- Code runs when it should not
- Code never runs
- Debug prints show unexpected behavior

### Cause
Using assignment (`=`) instead of comparison (`==`), or incorrect logical operators.

### Fix

❌ Incorrect:
```gdscript
if health = 0:
    die()
```

✅ Correct:
```gdscript
if health == 0:
    die()
```

Use `=` for assignment and `==` for comparison.

---

## Error: Missing `else` Case

### Symptoms
- State never resets
- Logic gets stuck
- Unexpected behavior after condition changes

### Cause
Only handling the `true` branch of a condition.

### Fix
```gdscript
if is_attacking:
    attack()
else:
    idle()
```

Always define behavior for both outcomes.

---

## Error: Multiple `if` Instead of `elif`

### Symptoms
- Multiple branches execute
- Conflicting logic runs in the same frame

### Cause
Using separate `if` statements when only one branch should execute.

### Fix

❌ Incorrect:
```gdscript
if health < 50:
    flee()
if health < 20:
    panic()
```

✅ Correct:
```gdscript
if health < 20:
    panic()
elif health < 50:
    flee()
```

Use `elif` for mutually exclusive conditions.

---

## Error: Logic Running Every Frame

### Symptoms
- Variables reset constantly
- Animations restart every frame
- State never changes as expected

### Cause
State-changing logic placed inside `_process()` or `_physics_process()` without guards.

### Fix
```gdscript
if not is_initialized:
    initialize()
    is_initialized = true
```

Avoid modifying state every frame unless required.

---

## Loops in GDScript

### `for` Loop (Preferred)
```gdscript
for enemy in enemies:
    enemy.attack()
```

### `while` Loop (Use Carefully)
```gdscript
while health > 0:
    health -= 1
```

---

## Error: Infinite Loop

### Symptoms
- Game freezes
- Editor becomes unresponsive
- CPU usage spikes

### Cause
Loop condition never becomes false.

### Fix

❌ Dangerous:
```gdscript
while true:
    do_something()
```

✅ Safe:
```gdscript
for i in range(10):
    do_something()
```

Avoid `while` loops unless absolutely necessary.

---

## `match` Statement

### Correct Usage
```gdscript
match state:
    "idle":
        idle()
    "attack":
        attack()
    _:
        idle()
```

---

## Error: Missing Default Case in `match`

### Symptoms
- No logic executes
- State appears broken

### Cause
Unhandled values in the `match` statement.

### Fix
Always include a default (`_`) case.

---

## Early Return (Recommended Pattern)

### Problem
Deep nesting hides bugs and complicates logic.

### Fix
```gdscript
func attack(target):
    if not target:
        return
    if target.health <= 0:
        return
    target.take_damage(10)
```

This improves readability and prevents hidden logic errors.

---

## Debugging Checklist for Control Flow Issues

Before assuming engine bugs, check:

- Are comparisons using `==` instead of `=`?
- Are `if` / `elif` branches mutually exclusive?
- Is logic unintentionally running every frame?
- Do loops always terminate?
- Does `match` include a default case?
- Are state changes properly guarded?
