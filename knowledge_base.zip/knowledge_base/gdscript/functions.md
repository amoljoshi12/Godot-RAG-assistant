---
topic: gdscript_functions
engine: godot4
language: gdscript
type: language
---

# Functions (GDScript – Godot 4)

## What Functions Are
Functions define reusable blocks of logic. In Godot, many bugs come from incorrect function signatures, wrong return values, or functions being called at the wrong time in the node lifecycle.

---

## Defining a Function

### Basic Function
```gdscript
func attack():
    print("Attack")
```

### Function With Parameters
```gdscript
func take_damage(amount: int):
    health -= amount
```

### Function With Return Value
```gdscript
func get_health() -> int:
    return health
```

---

## Typed Functions (Recommended)

Typing parameters and return values helps catch bugs early.

```gdscript
func calculate_damage(base: int, bonus: int) -> int:
    return base + bonus
```

Typed functions:
- Improve editor warnings
- Prevent accidental misuse
- Improve code readability

---

## Error: Function Never Called

### Symptoms
- Logic never runs
- No output or visible effect

### Cause
The function is defined but never invoked.

### Fix
Call the function explicitly.

```gdscript
attack()
```

---

## Error: Wrong Function Signature

### Symptoms
- Runtime error when function is called
- Unexpected behavior

### Cause
Function parameters do not match the call.

### Fix

❌ Incorrect:
```gdscript
func heal(amount: int):
    health += amount

heal()
```

✅ Correct:
```gdscript
heal(10)
```

Ensure the number and types of parameters match.

---

## Error: Missing Return Value

### Symptoms
- Function returns `null`
- Logic using return value fails

### Cause
The function declares a return type but does not return a value.

### Fix

❌ Incorrect:
```gdscript
func get_speed() -> int:
    speed += 10
```

✅ Correct:
```gdscript
func get_speed() -> int:
    return speed
```

---

## Early Return Pattern (Recommended)

Early returns reduce nesting and prevent invalid logic execution.

```gdscript
func attack(target):
    if not target:
        return
    if target.health <= 0:
        return
    target.take_damage(10)
```

---

## Functions and Node Lifecycle

Calling functions that access nodes before `_ready()` causes errors.

### Error: Function Called Too Early

#### Symptoms
- `null` references
- Node paths fail

#### Cause
Function is called before the node enters the scene tree.

#### Fix
Call such functions from `_ready()` or later.

---

## `_process()` vs `_physics_process()` Functions

- Use `_process(delta)` for frame-based logic
- Use `_physics_process(delta)` for physics logic

Putting the wrong logic in the wrong function causes inconsistent behavior.

---

## Anonymous Functions (Lambdas)

GDScript supports anonymous functions.

```gdscript
var double = func(x): return x * 2
print(double.call(4))
```

Use sparingly for small logic blocks.

---

## Debugging Checklist for Function Issues

Before assuming engine bugs, check:

- Is the function ever called?
- Do parameter counts and types match?
- Does the function return what it promises?
- Is it called at the correct lifecycle stage?
- Is the logic placed in the correct process function?
