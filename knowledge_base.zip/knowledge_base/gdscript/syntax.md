---
topic: gdscript_syntax
engine: godot4
language: gdscript
type: language
---

# GDScript Syntax (Godot 4)

## What GDScript Syntax Is
GDScript is an indentation-based, dynamically typed language. Most syntax-related bugs in Godot do not crash immediately but cause silent logic errors.

---

## Indentation Rules (CRITICAL)

GDScript uses indentation instead of braces to define scope.

### Error: Incorrect Indentation

#### Symptoms
- Code runs outside the intended block
- Logic executes even when conditions are false
- No syntax error, but wrong behavior

#### Cause
Incorrect or inconsistent indentation changes execution scope.

#### Fix

❌ Incorrect:
```gdscript
if is_alive:
print("Alive")
```

✅ Correct:
```gdscript
if is_alive:
    print("Alive")
```

Indentation defines logic. One misplaced space can break behavior.

---

## Colons After Control Statements

### Error: Missing Colon

#### Symptoms
- Script fails to run
- Parser error in editor

#### Cause
Control statements require a colon `:`.

#### Fix

❌ Incorrect:
```gdscript
if health > 0
    attack()
```

✅ Correct:
```gdscript
if health > 0:
    attack()
```

This applies to `if`, `elif`, `for`, `while`, `func`, and `match`.

---

## Case Sensitivity

### Error: Incorrect Capitalization

#### Symptoms
- Variable appears undefined
- `Identifier not found` error

#### Cause
GDScript is case-sensitive.

#### Fix

❌ Incorrect:
```gdscript
Speed = 10
velocity.x = speed
```

✅ Correct:
```gdscript
speed = 10
velocity.x = speed
```

---

## Tabs vs Spaces

### Error: Mixed Indentation

#### Symptoms
- Inconsistent logic execution
- Hard-to-trace bugs

#### Cause
Mixing tabs and spaces in indentation.

#### Fix
Use spaces only (recommended: 4 spaces).

---

## Error: Using `=` Instead of `==`

### Symptoms
- Condition always evaluates incorrectly
- Logic behaves unexpectedly

### Cause
`=` assigns values, `==` compares values.

### Fix

❌ Incorrect:
```gdscript
if health = 0:
    die()
```

✅ Correct:
```gdscript
if health == 0:
    die()
```

---

## Line Continuation

GDScript does not allow implicit line breaks.

### Correct Pattern
```gdscript
var damage = (
    base_damage +
    bonus_damage +
    critical_bonus
)
```

---

## Comments in GDScript

### Single-Line Comment
```gdscript
# This is a comment
```

### Multi-Line Comment
```gdscript
"""
This is a
multi-line comment
"""
```

---

## Debugging Checklist for Syntax Issues

Before assuming engine bugs, check:

- Is indentation correct?
- Are colons present after control statements?
- Are variable names case-consistent?
- Are `=` and `==` used correctly?
- Are tabs mixed with spaces?
