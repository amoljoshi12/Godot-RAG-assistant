---
topic: gdscript_variables
engine: godot4
language: gdscript
type: language
---

# Variables (GDScript – Godot 4)

## What Variables Are
Variables store state in a script. In Godot, many bugs come from incorrect typing, unexpected `null` values, or variables being modified at the wrong time.

---

## Declaring Variables

### Basic Declaration
```gdscript
var speed = 200
```

### Typed Variables (Recommended)
```gdscript
var speed: int = 200
```

Typed variables:
- Catch errors earlier
- Improve editor warnings
- Reduce silent logic bugs

---

## Error: Variable Is `null`

### Symptoms
- `Null instance` error
- Method calls fail at runtime
- Script crashes unexpectedly

### Cause
The variable was never assigned or depends on a node that is not ready.

### Fix
Always initialize variables or check for `null`.

```gdscript
var target: Node2D = null

if target:
    target.attack()
```

---

## Error: Variable Changes Unexpectedly

### Symptoms
- Value resets suddenly
- Logic behaves inconsistently
- Debug output changes every frame

### Cause
The variable is modified in multiple places or reset inside `_process()`.

### Fix
Initialize state once and avoid modifying it every frame unless required.

```gdscript
func _ready():
    health = max_health
```

---

## Typed vs Untyped Variables

### Untyped (Flexible but Risky)
```gdscript
var damage = 10
damage = "high"
```

### Typed (Safer)
```gdscript
var damage: int = 10
damage = "high" # Error
```

Typed variables prevent silent type-related bugs.

---

## Error: Variable Shadowing

### Symptoms
- Changes appear to have no effect
- Member variables never update

### Cause
A local variable shadows a member variable.

### Example
```gdscript
var score = 0

func add_score():
    var score = score + 1
```

### Fix
Do not redeclare member variables locally.

```gdscript
func add_score():
    score += 1
```

---

## `@export` Variables

Exported variables appear in the editor and can be modified per instance.

```gdscript
@export var speed: int = 200
```

### Common Mistake
Expecting runtime changes to update the editor value.

### Rule
- Editor values override script defaults
- Runtime changes do not persist in the editor

---

## Error: Accessing Variables Too Early

### Symptoms
- `null` references
- Incorrect default values

### Cause
Variables depend on nodes that are not yet ready.

### Fix
Assign node-dependent variables in `_ready()`.

```gdscript
func _ready():
    player = get_node("Player")
```

---

## Constants vs Variables

### Constant
```gdscript
const MAX_HEALTH = 100
```

Constants:
- Cannot change at runtime
- Prevent accidental modification

Use constants for fixed values.

---

## Debugging Checklist for Variable Issues

Before assuming engine bugs, check:

- Is the variable initialized?
- Can it be `null`?
- Is it typed correctly?
- Is it modified every frame?
- Is it shadowed by a local variable?
- Is it dependent on nodes not yet ready?
